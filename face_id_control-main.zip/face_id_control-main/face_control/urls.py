# urls.py

from django.urls import path
from .views import index, detect_people

urlpatterns = [
    path('', index, name='index'),
    path('detect_people/', detect_people, name='detect_people'),
]
