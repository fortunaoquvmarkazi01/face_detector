from django.contrib import messages
import time

from django.shortcuts import render
import cv2
import asyncio
from django.http import StreamingHttpResponse, request, JsonResponse


async def generate_frames():
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()

        # Odamlarni aniqlash uchun Haar kiritmalarini ishlatish
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        if len(faces) < 1 or len(faces) >= 2:
            # messages.success(request, 'Iltimos ekrandan uzoqlashmang va begonalar yaqinlashmasin')
            print('Begona')




        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        _, buffer = cv2.imencode('.jpg', frame)
        data = buffer.tobytes()
        response = (b'--frame\r\n'
                    b'Content-Type: image/jpeg\r\n\r\n' + data + b'\r\n')

        await asyncio.sleep(0.04)  # To avoid blocking

        yield response

    cap.release()

async def detect_people(request):
    return StreamingHttpResponse(generate_frames(), content_type="multipart/x-mixed-replace;boundary=frame")

async def index(request):
    return render(request, 'index.html')




