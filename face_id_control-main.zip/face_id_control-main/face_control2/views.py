from django.shortcuts import render
from django.http import StreamingHttpResponse
import cv2

# Global variables
seen_faces = set()
notification_sent = False

# Threshold for determining if faces are close enough
distance_threshold = 50  # Adjust this value based on your requirements


def are_faces_close(face1, face2):
    # Check if the distance between the centers of two faces is less than the threshold
    center1 = (face1[0] + face1[2] // 2, face1[1] + face1[3] // 2)
    center2 = (face2[0] + face2[2] // 2, face2[1] + face2[3] // 2)
    distance = ((center1[0] - center2[0]) ** 2 + (center1[1] - center2[1]) ** 2) ** 0.5
    return distance < distance_threshold


def gen_frames():
    global seen_faces, notification_sent

    # Open the camera (0 is usually the default camera)
    cap = cv2.VideoCapture(0)

    # Load the pre-trained Haar Cascade for face detection
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    while True:
        success, frame = cap.read()
        if not success:
            break

        # Convert the frame to grayscale for face detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Perform face detection
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        # Draw rectangles around the detected faces
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Trigger notification only when exactly two new faces are close and notification has not been sent
        new_faces = [face for face in faces if face.tobytes() not in seen_faces]
        if len(new_faces) == 2 and not notification_sent:
            print("begona")
            if are_faces_close(new_faces[0], new_faces[1]):
                send_notification()
                notification_sent = True  # Set the flag to indicate that notification has been sent
                break  # Break the loop after sending notification for tirik insonlar

        # Update the seen faces set
        seen_faces.update([face.tobytes() for face in faces])

        # Reset the flag when the number of new faces is not 2
        if len(new_faces) != 2:
            notification_sent = False

        # Convert the processed frame to JPEG format
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        # Yield the frame for streaming
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    # Release the camera when the streaming ends
    cap.release()


def send_notification():
    # Implement your notification mechanism here
    # For example, you can use Firebase Cloud Messaging (FCM)
    pass


def webcam(request):
    return render(request, 'webcam.html')


def video_feed(request):
    return StreamingHttpResponse(gen_frames(), content_type="multipart/x-mixed-replace;boundary=frame")


# New view to handle form submission
def process_form(request):
    if request.method == 'POST':
        message = request.POST.get('message', '')
        # Process the submitted message as needed
        # For example, you can save it to the database or perform some other action
        return render(request, 'done.html', {'message': message})
    else:
        # Handle the case when the form is accessed using a GET request
        return render(request, 'webcam.html')
