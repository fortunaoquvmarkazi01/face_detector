from django.urls import path
from .views import webcam, video_feed, process_form

urlpatterns = [
    path('webcam/', webcam, name='webcam'),
    path('video_feed/', video_feed, name='video_feed'),
    path('process_form/', process_form, name='process_form'),

]
