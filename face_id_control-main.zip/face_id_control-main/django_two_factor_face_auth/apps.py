from django.apps import AppConfig


class DjangoTwoFactorFaceAuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_two_factor_face_auth'
